from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(Fuel)
admin.site.register(Test)
admin.site.register(Package)
admin.site.register(Customer)
admin.site.register(Sample)
admin.site.register(SampleTest)