from django.shortcuts import render
from .models import *

# Create your views here.


def customers(request):
	customers = Customer.objects.all()
	context = {'customers':customers}
	return render(request, 'app/customers.html', context)